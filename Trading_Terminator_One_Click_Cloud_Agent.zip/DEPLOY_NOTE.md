ZIP को अपने-आप cloud account बनाकर deploy करने का अधिकार किसी local file को नहीं दिया जा सकता।
इस package को managed cloud host पर deploy करने और पहली बार Google/YouTube OAuth authorize करने की जरूरत होगी।
Production version में market-data API, voice provider, cloud storage, scheduler और video-rendering service connect करनी होगी।
