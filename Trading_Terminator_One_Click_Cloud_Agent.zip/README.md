# Trading Terminator One-Click Cloud Agent
Browser/cloud starter. No local Python, FFmpeg or Node required.
One-time cloud deployment and Google/YouTube OAuth approval are still required.
Default publishing mode is REVIEW/private for safety.
